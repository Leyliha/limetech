# Second task

A Pen created on CodePen.io. Original URL: [https://codepen.io/Leyliha/pen/gOqaoQM](https://codepen.io/Leyliha/pen/gOqaoQM).

